Expense Tracker
===============

Usage
-----

There currently isn't anything other than the models, so use the admin.
